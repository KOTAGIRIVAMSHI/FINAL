document.addEventListener("DOMContentLoaded", () => {
  const button = document.getElementById("tryFinanceTracker");
  
  button.addEventListener("click", () => {
    window.location.href = '../HOME PAGE/index.html'; // Redirect to index.html
  });
});
